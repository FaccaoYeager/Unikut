package unikut;

import java.util.Scanner;
public class Interface {
   public static void main(String[] args) {
       Scanner in = new Scanner (System.in);
       Scanner input = new Scanner (System.in);
       char opCont;
       boolean validCont = false;
       String email, senha, recado;
       Conta cont;
       ListaUnikut listCont = new ListaUnikut();
       Perfil perf = new Perfil();
       ContaAmigo contaAmg = new ContaAmigo();
       System.out.println("Bem-vindo a rede social Unikut.");
       System.out.println("Deseja cadastrar uma conta? Se sim, digite 1.");
       System.out.println("Se voc� j� tem uma conta, digite 2.");
       System.out.println("Digite aqui: ");
       opCont = in.next().charAt(0);
       while (opCont != '1' && opCont != '2') {
           System.out.print("Op��o inv�lida. Informe novamente: ");
           opCont = in.next().charAt(0);
       }
       System.out.println("Digite as informa��es necess�rias para a verifica��o da conta.");
       System.out.print("Email: ");
       email = input.nextLine();
       System.out.print("Senha :");
       senha = input.nextLine();
       cont = new Conta(email, senha);
       if (opCont == '1') {
           validCont = listCont.inserirConta(cont);
       }
       else {
           validCont = perf.entrarPerf(cont);
       }
       if (validCont = true) {
           menuUnikut();
           do {
               System.out.println();
               System.out.println("Digite 5 para ver o menu novamente.");
               System.out.print("Informe a sua op��o desejada: ");
               opCont = in.next().charAt(0);
               if (opCont == '1') {
                   perf.vizlPerf(cont);
               }
               else if (opCont == '2') {
                   perf.alterPerf(cont);
               }
               else if (opCont == '3') {
                   System.out.print("Informe o email da pessoa que deseja adicionar: ");
                   email = input.nextLine();
                   cont = new Conta(email);
                   contaAmg.adicioAmig(cont);
               }
               else if (opCont == '4') {
                   System.out.println("Informe o email da pessoa que gostaria de mandar um recado: ");
                   email = input.nextLine();
                   System.out.println("Informe aqui a sua mensagem: ");
                   recado = input.nextLine();
                   cont = new Conta(email);
                   contaAmg.adicionaRecado(cont, recado);
               }
               else if (opCont == '5') {
                   menuUnikut();
               }
               else if (opCont == '0'){
                   System.out.println("Esperamos te ver de novo por aqui.");
               }
               else {
                   System.out.println("Op��o inv�lida.");
               }
           } while (opCont != '0');
       }
   }

   public static void menuUnikut() {
       System.out.println("Op��es da rede social Unikut:");
       System.out.println("1 - Vizualizar perfil.");
       System.out.println("2 - Editar perfil.");
       System.out.println("3 - Op��es para adicionar usu�rios na lista de amigos.");
       System.out.println("4 - Mandar mensagem para outra conta cadastrada.");
       System.out.println("0 - Desconectar do site Unikut.");
   }
}
