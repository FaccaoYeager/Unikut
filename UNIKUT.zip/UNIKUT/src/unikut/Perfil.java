package unikut;

import java.util.Scanner;

public class Perfil {
	Scanner in = new Scanner(System.in);
	Scanner input = new Scanner(System.in);
	Node aux;
	ListaUnikut listCont = new ListaUnikut();

	public void editarNome(Conta cont) {
		char opNome;
		String nome;
		System.out.println("Deseja informar o seu nome? Se sim, digite s. Se n�o, digite n.");
		System.out.print("Digite aqui: ");
		opNome = in.next().charAt(0);
		if (opNome == 's' || opNome == 'S') {
			System.out.print("Informe aqui o seu nome: ");
			nome = input.nextLine();
			cont.setNome(nome);
		} else {
			System.out.println("O seu nome no perfil aparecer� como convidado.");
		}
	}

	public boolean entrarPerf(Conta cont) {
		aux = listCont.buscaList(cont);
		if (aux == null) {
			System.out.println("Conta n�o cadastrada.");
		} else if (aux.getInfo().getSenha().compareTo(cont.getSenha()) != 0) {
			System.out.println("Senha incorreta.");
		} else {
			System.out.println("Seja bem-vindo.");
			return true;
		}
		return false;
	}

	public void vizlPerf(Conta cont) {
		aux = listCont.buscaList(cont);
		System.out.println(aux.getInfo());
	}

	public void alterPerf(Conta cont) {
		char opAlt;
		String senha, sexo, anivers, estadCiv, descric;
		int idade;
		System.out.println("Op��es para alter��o:");
		System.out.println("1 - Senha.");
		System.out.println("2 - Idade.");
		System.out.println("3 - Sexo.");
		System.out.println("4 - Anivers�rio.");
		System.out.println("5 - Estado civil.");
		System.out.println("6 - Descri��o do seu perfil.");
		System.out.println("7 - Altera todas as op��es exibidas perfil (Conta recentemente criada).");
		System.out.print("Digite aqui: ");
		opAlt = in.next().charAt(0);
		if (opAlt == '1') {
			System.out.print("Informe a sua nova senha: ");
			senha = input.nextLine();
			cont.setSenha(senha);
		} else if (opAlt == '2') {
			System.out.print("Informe a sua nova idade: ");
			idade = in.nextInt();
			cont.setIdade(idade);
		} else if (opAlt == '3') {
			System.out.print("Informe o seu sexo: ");
			sexo = input.nextLine();
			cont.setSexo(sexo);
		} else if (opAlt == '4') {
			System.out.print("Informe a data do seu anivers�rio para altera��o: ");
			anivers = input.nextLine();
			cont.setAnivers(anivers);
		} else if (opAlt == '5') {
			System.out.print("Informe o seu novo estado civil: ");
			estadCiv = input.nextLine();
			cont.setEstadCiv(estadCiv);
		} else if (opAlt == '6') {
			System.out.print("Informe uma nova descri��o para o seu perfil: ");
			descric = input.nextLine();
			cont.setDescric(descric);
		} else if (opAlt == '7') {
			System.out.print("Informe a sua nova idade: ");
			idade = in.nextInt();
			cont.setIdade(idade);
			System.out.print("Informe o seu sexo: ");
			sexo = input.nextLine();
			cont.setSexo(sexo);
			System.out.print("Informe a data do seu anivers�rio para altera��o: ");
			anivers = input.nextLine();
			cont.setAnivers(anivers);
			System.out.print("Informe o seu novo estado civil: ");
			estadCiv = input.nextLine();
			cont.setEstadCiv(estadCiv);
			System.out.print("Informe uma nova descri��o para o seu perfil: ");
			descric = input.nextLine();
			cont.setDescric(descric);
		} else {
			System.out.println("Op��o inv�lida.");
		}
	}
}
