package unikut;

public class ListaUnikut {
   private Node primer;
   private Node ultim;
   private int qnt;

   public boolean incerirConta(Conta cont) {
       Node aux;
       int compara;
       Node listCont = new Node(cont);
       Perfil perf = new Perfil();
       if (this.isEmpty() == true) {
           this.primer = listCont;
           this.ultim = listCont;
       }
       else {
           if (this.primer.getInfo().compareTo(cont) > 0) {
               listCont.setProx(this.primer);
               this.primer.setAnte(listCont);
               this.primer = listCont;
           }
           else if (this.ultim.getInfo().compareTo(cont) < 0) {
               listCont.setAnte(this.ultim);
               this.ultim.setProx(listCont);
               this.ultim = listCont;
           }
           else {
               aux = this.primer;
               while (aux != null) {
                   compara = aux.getInfo().compareTo(cont);
                   if (compara == 0) {
                       System.out.println("Email cadastrado anteriormente. Tente outro email.");
                       return false;
                   }
                   else if (compara > 0) {
                       aux.getAnte().setProx(listCont);
                       listCont.setAnte(aux.getAnte());
                       aux.setAnte(listCont);
                       listCont.setProx(aux);
                       break;
                   }
                   aux = aux.getProx();
               }
           }
       }
       this.qnt++;
       System.out.println("Conta cadastrada.");
       perf.editarNome(cont);
       return true;
   }

   private boolean isEmpty() {
       if (this.primer == null && this.ultim == null && this.qnt == 0) {
           return true;
       }
       return false;
   }

   public Node buscaList(Conta bcCont) {
       Node aux;
       int compara;
       aux = this.primer;
       while (aux != null) {
           compara = aux.getInfo().compareTo(bcCont);
           if (compara == 0) {
               return aux;
           }
           else if (compara > 0) {
               return null;
           }
           aux = aux.getProx();
       }
       return null;
   }
}
