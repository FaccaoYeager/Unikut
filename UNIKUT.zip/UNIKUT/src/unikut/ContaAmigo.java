package unikut;

import java.util.Scanner;

public class ContaAmigo {
	Scanner in = new Scanner(System.in);
	Scanner input = new Scanner(System.in);

	public void adicioAmig(Conta cont) {
		char opAdc;
		String email;
		Node amg;
		Conta solicAmg = new Conta();
		ListaUnikut list = new ListaUnikut();
		System.out.println("Op��es para solicita��es de amizade:");
		System.out.println("1 - Adicionar amigo.");
		System.out.println("2 - Status de amizades.");
		System.out.println("3 - Aceitar solicita��es.");
		do {
			System.out.println("Digite 4 para rever o menu de op��es.");
			System.out.println("Digite aqui: ");
			opAdc = in.next().charAt(0);
			in.nextLine();
			if (opAdc == '1') {
				amg = list.buscaList(cont);
				if (amg != null && amg.getInfo().compareTo(cont) != 0) {
					list.incerirConta(cont);
					System.out.println("Solicita��o enviada.");
				} else {
					System.out.println("Conta de amigo n�o cadastrada!");
				}
			} else if (opAdc == '2') {
				solicAmg.listaAmigos();
			} else if (opAdc == '3') {
				System.out.println("Informe o login do usu�rio para alterar status:");
				email = in.nextLine();
				Conta cont2 = new Conta(email);
				amg = list.buscaList(cont2);
				if (amg != null && amg.getInfo().compareTo(cont2) != 0) {
					conta2.alteraStatusAmigos(amg);
					System.out.println("Status de amigo, atualizado!");
				} else {
					System.out.println("Login n�o encontrado!");
				}
				break;
			} else if (opAdc == '4') {
				System.out.println("De volta � conta.");
			} else {
				System.out.println("Escolha inv�lida. Tente novamente.");
			}
		} while (opAdc != '4');
	}

	public void alteraStatusAmigos(Conta amg) {
		ListaUnikut list = new ListaUnikut();
		Node amg2;
		amg2 = list.buscaList(amg);
		if (amg2 != null) {
			if (amg2.getStatus().compareTo("pendente") == 0) {
				amg2.setStatus();
			} else {
				System.out.println("Solicita��o j� atualizada.");
			}
		} else {
			System.out.println("Amigo ou conta n�o existente.");
		}
	}

	public void adicionaRecado(Conta cont, String recad) {
		recados.add(cont.getNome() + ": " + recad);
	}
}
