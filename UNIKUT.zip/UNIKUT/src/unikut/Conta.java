package Unikut;
public class Conta {
   private String email;
   private String senha;
   private String nome = "Convidado";
   private int idade = 0;
   private String sexo = "Sem informa��o";
   private String anivers = "Sem informa��o";
   private String estadCiv = "Sem informa��o";
   private String descric = "Sem informa��o";
   private Conta amigo;

   public Conta (String eml, String senh) {
       this.email = eml;
       this.senha = senh;
   }

   public Conta (String eml) {
       this.email = eml;
   }

   public String getEmail() {
       return this.email;
   }

   public String getSenha() {
       return this.senha;
   }

   public String getNome() {
       return this.nome;
   }

   public void setSenha(String senh) {
       this.senha = senh;
   }

   public void setNome(String nom) {
       this.nome = nom;
   }

   public void setIdade(int idade) {
       this.idade = idade;
   }

   public void setSexo(String sexo) {
       this.sexo = sexo;
   }

   public void setAnivers(String anivers) {
       this.anivers = anivers;
   }

   public void setEstadCiv(String estadCiv) {
       this.estadCiv = estadCiv;
   }

   public void setDescric(String descric) {
       this.descric = descric;
   }

   public int compareTo(Conta bcCont) {
       int compara;
       compara = this.email.compareTo(bcCont.getEmail());
       return compara;
   }

   public String toString() {
       return "Email: " + this.email + ", nome: " + this.nome + ", idade: " + this.idade + ", sexo: " + this.sexo + ", data de anivers�rio: " + this.anivers + ", estado civil: " + this.estadCiv + " e descri��o do perfil^: " + this.descric + ".";
   }

   public void listaAmigos(){
       int i = 0;
       Conta aux = amg.getPrimer();
       Conta ultim = amigo.getUltim();
       while(aux != null){
           System.out.println(aux);
           if(amigo.indexOf(ultim) == i){
               return;
           }
           else{
               aux = amigo.get(i + 1);
           }
       }
   }
}
